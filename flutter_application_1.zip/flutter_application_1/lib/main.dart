import 'package:flutter_application_1/view/tela_login.dart';
import 'package:flutter_application_1/view/tela_cadastro.dart';
import 'package:flutter_application_1/view/tela_principal.dart';
import 'package:flutter_application_1/view/tela_sobre.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Papelaria',
      initialRoute: 'tela1',
      routes: {
        'tela1': (context) => const TelaLogin(),
        'tela2': (context) => const TelaCadastro(),
        'tela3': (context) => const TelaPrincipal(),
        'tela4': (context) => const TelaSobre(),
      },
    ),
  );
}
