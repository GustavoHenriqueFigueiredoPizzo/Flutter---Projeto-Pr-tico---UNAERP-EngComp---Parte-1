import 'package:flutter/material.dart';

import 'widget_sobre.dart';

class TelaSobre extends StatefulWidget {
  const TelaSobre({Key? key}) : super(key: key);

  @override
  _TelaSobreState createState() => _TelaSobreState();
}

class _TelaSobreState extends State<TelaSobre> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Papelaria',
          style: TextStyle(
              fontSize: 20.0,
              fontFamily: 'Papernotes',
              fontWeight: FontWeight.w300),
        ),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      body: SingleChildScrollView(
          child: Center(
        child: Column(children: const [
          WidgetSobre("Gustavo H. F. Pizzo", "assets/images/Gustavo.jpg"),
          WidgetSobre(
              "Aplicativo desenvolvido para auxiliar pessoas na compra de material escolar.",
              "assets/images/papelaria.jpg"),
        ]),
      )),
      drawer: Container(
        color: Colors.lightBlue,
        child: Column(children: [
          TextButton(
            style: TextButton.styleFrom(),
            onPressed: () {
              Navigator.pushNamed(context, 'tela3');
            },
            child: const Text("Tela Principal",
                style: const TextStyle(
                    color: Colors.black,
                    fontSize: 30,
                    fontFamily: 'Papernotes')),
          ),
          TextButton(
            style: TextButton.styleFrom(),
            onPressed: () {
              Navigator.pushNamed(context, 'tela4');
            },
            child: const Text("Sobre",
                style: const TextStyle(
                    color: Colors.black,
                    fontSize: 30,
                    fontFamily: 'Papernotes')),
          )
        ]),
      ),
    );
  }
}
