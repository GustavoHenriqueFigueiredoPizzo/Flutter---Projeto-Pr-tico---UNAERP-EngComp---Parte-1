import 'package:flutter/material.dart';

import 'widget_detalhes.dart';

class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({Key? key}) : super(key: key);

  @override
  _TelaPrincipalState createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Papelaria',
          style: TextStyle(
              fontSize: 20.0,
              fontFamily: 'Papernotes',
              fontWeight: FontWeight.w300),
        ),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      body: SingleChildScrollView(
          child: Center(
        child: Column(children: const [
          WidgetDetalhes("Caneta", "assets/images/Caneta.jpg"),
          WidgetDetalhes("Lápis", "assets/images/Lapis.jpg"),
          WidgetDetalhes("Borracha", "assets/images/Borracha.jpg"),
          WidgetDetalhes("Estojo", "assets/images/Estojo.jpg"),
        ]),
      )),
      drawer: Container(
        color: Colors.blue,
        child: Column(children: [
          TextButton(
            style: TextButton.styleFrom(),
            onPressed: () {
              Navigator.pushNamed(context, 'tela3');
            },
            child: const Text("Tela Principal",
                style: const TextStyle(
                    color: Colors.black,
                    fontSize: 30,
                    fontFamily: 'Papernotes')),
          ),
          TextButton(
            style: TextButton.styleFrom(),
            onPressed: () {
              Navigator.pushNamed(context, 'tela4');
            },
            child: const Text("Sobre",
                style: const TextStyle(
                    color: Colors.black,
                    fontSize: 30,
                    fontFamily: 'Papernotes')),
          )
        ]),
      ),
    );
  }
}
