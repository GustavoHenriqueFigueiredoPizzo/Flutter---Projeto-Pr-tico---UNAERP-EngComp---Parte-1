import 'package:flutter/material.dart';

class TelaLogin extends StatefulWidget {
  const TelaLogin({Key? key}) : super(key: key);

  @override
  _TelaLoginState createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  var txtEmail = TextEditingController();
  var txtSenha = TextEditingController();
  var form = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(30),
          child: Center(
            child: Form(
              key: form,
              child: Column(
                children: [
                  const Icon(
                    Icons.person_outline_rounded,
                    size: 100,
                  ),
                  const Text(
                    'Login',
                    style: TextStyle(
                        fontSize: 24,
                        fontFamily: 'Papernotes',
                        fontWeight: FontWeight.w300),
                  ),
                  const SizedBox(height: 30),
                  campoTexto('Email', txtEmail, false),
                  const SizedBox(height: 10),
                  campoTexto('Senha', txtSenha, true),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      botao('Cadastro', 'tela2'),
                      botao('Login', 'tela3'),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  campoTexto(rotulo, variavel, obscuro) {
    return TextFormField(
      controller: variavel,
      style: const TextStyle(
          fontSize: 24, fontFamily: 'Papernotes', fontWeight: FontWeight.w300),
      keyboardType: TextInputType.text,
      maxLength: 30,
      decoration: InputDecoration(
        labelText: rotulo,
        labelStyle: const TextStyle(
            fontSize: 24,
            fontFamily: 'Papernotes',
            fontWeight: FontWeight.w300),
        hintStyle: TextStyle(
          fontSize: 18,
          color: Colors.grey.shade400,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }

  botao(rotulo, dir) {
    return SizedBox(
      width: 150,
      height: 60,
      child: ElevatedButton(
        onPressed: () {
          Navigator.pushNamed(context, dir);
        },
        child: Text(
          rotulo,
          style: const TextStyle(
              fontSize: 20,
              fontFamily: 'Papernotes',
              fontWeight: FontWeight.w300),
        ),
        style: ElevatedButton.styleFrom(
          primary: Colors.blueGrey,
        ),
      ),
    );
  }
}
