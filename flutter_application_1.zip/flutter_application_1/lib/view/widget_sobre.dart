import 'package:flutter/material.dart';

class WidgetSobre extends StatelessWidget {
  final String nome;
  final String imagem;

  const WidgetSobre(this.nome, this.imagem, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(40, 40, 40, 0),
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        border: Border.all(
          width: 2.0,
          color: Colors.black,
        ),
        color: Colors.blue.shade100,
        borderRadius: BorderRadius.circular(20),
      ),
      width: MediaQuery.of(context).size.width * 0.90,
      height: 380,
      child: Column(
        children: [
          Text(
            nome,
            style: const TextStyle(
              fontFamily: 'Papernotes',
              fontSize: 28,
              fontWeight: FontWeight.normal,
              color: Colors.black,
            ),
          ),
          Image.asset(
            imagem,
            scale: 1.5,
          ),
        ],
      ),
    );
  }
}
